# AAUTO'S landing page (draft v1)

Static HTML/CSS/JS, no build step. Implements the homepage from the implementation plan.

## Run
Open `index.html`, or serve it: `python3 -m http.server 8000` (or `npx serve`).

## Files
- `index.html` – all sections (header, hero + search, Net binnen, services + finance calculator, trust, team, trade-in, reviews, visit us, footer, mobile bar)
- `css/styles.css` – design tokens at the top (`:root`): paper/ink, accent, kenteken yellow, fonts
- `js/main.js` – `CONFIG` (phone, WhatsApp, opening hours, finance rate, lead endpoint), search, cards, favorites, compare, calculator, open/closed
- `data/cars.js` – DEMO stock; replace with Mobilox feed/API and add the title parser (plan 7.3)
- `assets/` – add `hero.mp4`, `hero.webm`, `hero-poster.jpg` (plan 4.2 video specs); fonts in `assets/fonts/`

## TODO before launch
1. Logo + accent color (`--accent`), real fonts (uncomment `@font-face`)
2. Real phone, WhatsApp, KvK, hours (all marked TODO)
3. Trust checks, warranty text, team names: only dealer-confirmed claims
4. Google Reviews widget, RDW plate lookup, lead endpoint, cookie consent
5. Mobilox API/feed decision (plan 7.1), redirect map, structured data for cars
