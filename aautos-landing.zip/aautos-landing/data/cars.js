// DEMO DATA. Replace with Mobilox feed/API (see README). Fields follow plan section 7.3.
window.CARS = [
 {id:"demo-1",make:"Fiat",model:"500",variant:"1.2 Lounge",chips:["Panorama","Airco","NAP","Lage km"],price:8950,year:2019,km:48200,fuel:"Benzine",trans:"Handgeschakeld",apk:"2027-03",plate:"AB-123-C"},
 {id:"demo-2",make:"Volkswagen",model:"Golf",variant:"1.5 TSI Life",chips:["Navigatie","Cruise control","Trekhaak"],price:21450,year:2021,km:39800,fuel:"Benzine",trans:"Automaat",apk:"2028-01",plate:"DE-456-F"},
 {id:"demo-3",make:"Peugeot",model:"208",variant:"1.2 PureTech Active",chips:["Apple CarPlay","Airco"],price:13900,year:2020,km:61000,fuel:"Benzine",trans:"Handgeschakeld",apk:"2027-09",plate:"GH-789-J"},
 {id:"demo-4",make:"Toyota",model:"Yaris",variant:"1.5 Hybrid Dynamic",chips:["Hybride","Camera","NAP"],price:17250,year:2021,km:33500,fuel:"Hybride",trans:"Automaat",apk:"2028-05",plate:"KL-012-M"},
 {id:"demo-5",make:"Kia",model:"Picanto",variant:"1.0 DPi ComfortLine",chips:["Airco","Lage km"],price:11450,year:2020,km:27400,fuel:"Benzine",trans:"Handgeschakeld",apk:"2027-11",plate:"NP-345-Q"},
 {id:"demo-6",make:"Renault",model:"Zoe",variant:"R135 Intens",chips:["Elektrisch","Navigatie"],price:12800,year:2020,km:44100,fuel:"Elektrisch",trans:"Automaat",apk:"2027-07",plate:"RS-678-T"}
];
