// ---- CONFIG: fill in with confirmed dealer data ----
const CONFIG = {
  phone: "+31000000000", phoneLabel: "000-0000000", whatsapp: "31000000000",
  // 0 = zondag, null = gesloten. TODO: bevestigen met dealer
  hours: {1:[9,18],2:[9,18],3:[9,18],4:[9,18],5:[9,18],6:[10,17],0:null},
  apr: 0.079,
  leadEndpoint: null // TODO: POST-endpoint voor formulieren (e-mail / lead inbox)
};
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const eur = n => "€ " + Math.round(n).toLocaleString("nl-NL");
const store = { get(k){ try { return JSON.parse(localStorage.getItem(k)) || []; } catch { return []; } },
                set(k,v){ try { localStorage.setItem(k, JSON.stringify(v)); } catch {} } };
let cars = window.CARS || [];   // TODO: swap for fetch() to your stock API
let favs = store.get("favs"), cmp = [];

$$("[data-tel]").forEach(a => { a.href = "tel:" + CONFIG.phone; if (a.classList.contains("tel")) a.textContent = CONFIG.phoneLabel; });
$$("[data-wa]").forEach(a => a.href = "https://wa.me/" + CONFIG.whatsapp);

const mb = $(".menu-btn");
mb.onclick = () => { const o = $("#nav").classList.toggle("open"); mb.setAttribute("aria-expanded", o); };
$$("#nav a").forEach(a => a.onclick = () => { $("#nav").classList.remove("open"); mb.setAttribute("aria-expanded", false); });

// hero video: poster only on data-saver / slow connections
const v = $(".hero-video"), conn = navigator.connection;
if (conn && (conn.saveData || /2g/.test(conn.effectiveType))) { v.removeAttribute("autoplay"); v.pause(); v.innerHTML = ""; }

// ---- search ----
const f = $("#search"), uniq = k => [...new Set(cars.map(c => c[k]))].sort();
const fill = (sel, vals) => vals.forEach(x => sel.add(new Option(typeof x === "number" ? "Tot " + eur(x) : x, x)));
fill(f.make, uniq("make")); fill(f.fuel, uniq("fuel")); fill(f.price, [10000,15000,20000,25000,30000]);
const match = () => cars.filter(c => (!f.make.value || c.make === f.make.value) && (!f.model.value || c.model === f.model.value)
  && (!f.price.value || c.price <= +f.price.value) && (!f.fuel.value || c.fuel === f.fuel.value));
function updateModels(){ const cur = f.model.value; f.model.length = 1;
  fill(f.model, [...new Set(cars.filter(c => !f.make.value || c.make === f.make.value).map(c => c.model))].sort()); f.model.value = cur; }
function updateCount(){ $("#count").textContent = match().length; $("#count2").textContent = cars.length; }
f.make.onchange = () => { f.model.value = ""; updateModels(); updateCount(); };
[f.model, f.price, f.fuel].forEach(e => e.onchange = updateCount);
f.onsubmit = e => { e.preventDefault(); render(match()); $("#aanbod").scrollIntoView(); };

// ---- cars ----
function card(c){
  const fav = favs.includes(c.id);
  return `<li class="card">
   <div class="photo"><span>Foto volgt</span><span class="plate" aria-label="Kenteken ${c.plate}">${c.plate}</span></div>
   <div class="card-b"><h3>${c.make} ${c.model}</h3><p class="variant">${c.variant}</p>
    <ul class="chips">${c.chips.map(x => `<li>${x}</li>`).join("")}</ul>
    <dl class="specs"><div><dt>Bouwjaar</dt><dd>${c.year}</dd></div><div><dt>Km-stand</dt><dd>${c.km.toLocaleString("nl-NL")}</dd></div>
     <div><dt>APK tot</dt><dd>${c.apk}</dd></div><div><dt>Brandstof</dt><dd>${c.fuel}</dd></div></dl>
    <div class="price">${eur(c.price)}</div>
    <div class="card-a"><label><input type="checkbox" data-cmp="${c.id}" ${cmp.includes(c.id) ? "checked" : ""}>Vergelijk</label>
     <button class="fav" data-fav="${c.id}" aria-pressed="${fav}">${fav ? "Bewaard" : "Bewaar"}</button></div>
   </div></li>`;
}
function render(list){ $("#cars").innerHTML = list.length ? list.slice(0, 6).map(card).join("") : `<li class="empty">Geen auto's gevonden. Pas de zoekopdracht aan of <a href="#contact">bel ons</a>.</li>`; }
$("#cars").addEventListener("click", e => {
  const b = e.target.closest("[data-fav]"); if (!b) return;
  const id = b.dataset.fav; favs = favs.includes(id) ? favs.filter(x => x !== id) : [...favs, id]; store.set("favs", favs);
  b.setAttribute("aria-pressed", favs.includes(id)); b.textContent = favs.includes(id) ? "Bewaard" : "Bewaar";
});
$("#cars").addEventListener("change", e => {
  const id = e.target.dataset.cmp; if (!id) return;
  if (e.target.checked && cmp.length >= 3) { e.target.checked = false; return; }
  cmp = e.target.checked ? [...cmp, id] : cmp.filter(x => x !== id);
  $("#tray").hidden = !cmp.length; $("#tray-n").textContent = cmp.length + " van 3 gekozen";
});
$("#tray-go").onclick = () => {
  const L = cmp.map(id => cars.find(c => c.id === id)), rows = [["Prijs","price"],["Bouwjaar","year"],["Km-stand","km"],["Brandstof","fuel"],["Transmissie","trans"],["APK tot","apk"]];
  $("#cmp-body").innerHTML = `<table><tr><th></th>${L.map(c => `<th>${c.make} ${c.model}</th>`).join("")}</tr>${rows.map(([n,k]) =>
    `<tr><th>${n}</th>${L.map(c => `<td>${k === "price" ? eur(c[k]) : c[k]}</td>`).join("")}</tr>`).join("")}</table>`;
  $("#cmp").showModal();
};
$$(".arrow").forEach(a => a.onclick = () => $("#cars").scrollBy({ left: a.dataset.dir * 340, behavior: "smooth" }));

// ---- finance calculator ----
const calc = $("#calc");
function pay(){ const P = Math.max(0, +calc.price.value - +calc.down.value), n = +calc.term.value, r = CONFIG.apr / 12;
  $("#monthly").textContent = eur(P * r / (1 - Math.pow(1 + r, -n))); }
calc.oninput = pay; pay();

// ---- opening hours (Europe/Amsterdam) ----
function hours(){
  const p = Object.fromEntries(new Intl.DateTimeFormat("en-GB", { timeZone: "Europe/Amsterdam", weekday: "short", hour: "numeric", minute: "numeric", hourCycle: "h23" }).formatToParts(new Date()).map(x => [x.type, x.value]));
  const d = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"].indexOf(p.weekday), t = +p.hour + +p.minute / 60, h = CONFIG.hours[d];
  const open = !!(h && t >= h[0] && t < h[1]), el = $("#open");
  el.textContent = open ? "Nu geopend" : "Gesloten"; el.className = "open " + (open ? "yes" : "no");
  const names = ["Zondag","Maandag","Dinsdag","Woensdag","Donderdag","Vrijdag","Zaterdag"];
  $("#hours").innerHTML = [1,2,3,4,5,6,0].map(i => { const x = CONFIG.hours[i];
    return `<tr class="${i === d ? "today" : ""}"><td>${names[i]}</td><td>${x ? x[0] + ":00 – " + x[1] + ":00" : "Gesloten"}</td></tr>`; }).join("");
}
hours();

// ---- forms ----
async function lookupPlate(plate){ /* TODO: RDW open data lookup (opendata.rdw.nl) */ return null; }
async function sendLead(type, form){
  const st = $(".status", form), data = Object.fromEntries(new FormData(form)); data.type = type;
  if (type === "inruilen" && data.plate) data.rdw = await lookupPlate(data.plate);
  try {
    if (!CONFIG.leadEndpoint) throw new Error("no endpoint");
    const r = await fetch(CONFIG.leadEndpoint, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });
    if (!r.ok) throw new Error(r.status);
    st.textContent = "Verstuurd. We reageren zo snel mogelijk."; form.reset();
  } catch { st.textContent = "Versturen is nog niet gekoppeld. Bel of app ons: " + CONFIG.phoneLabel; console.info("Lead (not sent):", data); }
}
$("#trade").onsubmit = e => { e.preventDefault(); sendLead("inruilen", e.target); };
$("#contact-form").onsubmit = e => { e.preventDefault(); sendLead("contact", e.target); };

updateModels(); updateCount(); render(cars);
